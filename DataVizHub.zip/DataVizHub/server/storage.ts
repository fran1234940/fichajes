import { 
  users, type User, type InsertUser,
  shifts, type Shift, type InsertShift,
  vacationRequests, type VacationRequest, type InsertVacationRequest
} from "@shared/schema";
import { differenceInHours, differenceInSeconds, formatISO, parseISO, subHours } from "date-fns";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  
  // Shift operations
  createShift(shift: InsertShift): Promise<Shift>;
  getShiftById(id: number): Promise<Shift | undefined>;
  getShiftsByUserId(userId: number): Promise<Shift[]>;
  getActiveShiftByUserId(userId: number): Promise<Shift | undefined>;
  updateShift(id: number, shiftData: Partial<Shift>): Promise<Shift | undefined>;
  getAllShifts(): Promise<Shift[]>;
  
  // Vacation request operations
  createVacationRequest(request: InsertVacationRequest): Promise<VacationRequest>;
  getVacationRequestsByUserId(userId: number): Promise<VacationRequest[]>;
  updateVacationRequest(id: number, requestData: Partial<VacationRequest>): Promise<VacationRequest | undefined>;
  getAllVacationRequests(): Promise<VacationRequest[]>;
  getVacationRequestById(id: number): Promise<VacationRequest | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private shifts: Map<number, Shift>;
  private vacationRequests: Map<number, VacationRequest>;
  private userCounter: number;
  private shiftCounter: number;
  private vacationRequestCounter: number;

  constructor() {
    this.users = new Map();
    this.shifts = new Map();
    this.vacationRequests = new Map();
    this.userCounter = 1;
    this.shiftCounter = 1;
    this.vacationRequestCounter = 1;
    
    // Create default admin user
    this.createUser({
      username: "admin",
      password: "1234",
      fullName: "Administrator",
      email: "admin@worktrack.com",
      role: "admin"
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.userCounter++;
    const user: User = { id, ...userData };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Shift operations
  async createShift(shiftData: InsertShift): Promise<Shift> {
    const id = this.shiftCounter++;
    const shift: Shift = { 
      id, 
      ...shiftData,
      hasIncident: false,
    };
    this.shifts.set(id, shift);
    return shift;
  }

  async getShiftById(id: number): Promise<Shift | undefined> {
    return this.shifts.get(id);
  }

  async getShiftsByUserId(userId: number): Promise<Shift[]> {
    return Array.from(this.shifts.values()).filter(
      (shift) => shift.userId === userId
    );
  }

  async getActiveShiftByUserId(userId: number): Promise<Shift | undefined> {
    return Array.from(this.shifts.values()).find(
      (shift) => shift.userId === userId && shift.status === "in_progress"
    );
  }

  async updateShift(id: number, shiftData: Partial<Shift>): Promise<Shift | undefined> {
    const shift = await this.getShiftById(id);
    if (!shift) return undefined;
    
    // Calculate total hours if the shift is ending
    let updatedData = { ...shiftData };
    
    if (shiftData.endTime && !shift.endTime) {
      let totalWorkingSeconds = 0;
      
      // Calculate total seconds worked
      if (shift.breakStartTime && shift.breakEndTime) {
        // Include break
        const breakDurationSeconds = differenceInSeconds(
          new Date(shift.breakEndTime),
          new Date(shift.breakStartTime)
        );
        
        totalWorkingSeconds = differenceInSeconds(
          new Date(shiftData.endTime),
          new Date(shift.startTime)
        ) - breakDurationSeconds;
      } else if (shift.breakStartTime && !shift.breakEndTime) {
        // Break started but not ended before shift end
        const workBeforeBreakSeconds = differenceInSeconds(
          new Date(shift.breakStartTime),
          new Date(shift.startTime)
        );
        totalWorkingSeconds = workBeforeBreakSeconds;
      } else {
        // No break
        totalWorkingSeconds = differenceInSeconds(
          new Date(shiftData.endTime),
          new Date(shift.startTime)
        );
      }
      
      // Convert seconds to hours and format as HH:MM:SS
      const hours = Math.floor(totalWorkingSeconds / 3600);
      const minutes = Math.floor((totalWorkingSeconds % 3600) / 60);
      const seconds = totalWorkingSeconds % 60;
      
      const totalHoursString = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
      
      // Check if this shift has an incident (less than 8 hours)
      const hasIncident = hours < 8;
      
      updatedData = { 
        ...updatedData, 
        totalHours: totalHoursString,
        hasIncident,
        status: "completed"
      };
    }
    
    const updatedShift = { ...shift, ...updatedData };
    this.shifts.set(id, updatedShift);
    return updatedShift;
  }

  async getAllShifts(): Promise<Shift[]> {
    return Array.from(this.shifts.values());
  }

  // Vacation request operations
  async createVacationRequest(requestData: InsertVacationRequest): Promise<VacationRequest> {
    const id = this.vacationRequestCounter++;
    const request: VacationRequest = { 
      id, 
      ...requestData, 
      status: "pending", 
      createdAt: new Date().toISOString() 
    };
    this.vacationRequests.set(id, request);
    return request;
  }

  async getVacationRequestsByUserId(userId: number): Promise<VacationRequest[]> {
    return Array.from(this.vacationRequests.values())
      .filter((request) => request.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async updateVacationRequest(id: number, requestData: Partial<VacationRequest>): Promise<VacationRequest | undefined> {
    const request = await this.getVacationRequestById(id);
    if (!request) return undefined;
    
    const updatedRequest = { ...request, ...requestData };
    this.vacationRequests.set(id, updatedRequest);
    return updatedRequest;
  }

  async getAllVacationRequests(): Promise<VacationRequest[]> {
    return Array.from(this.vacationRequests.values());
  }

  async getVacationRequestById(id: number): Promise<VacationRequest | undefined> {
    return this.vacationRequests.get(id);
  }
}

export const storage = new MemStorage();
