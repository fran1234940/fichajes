import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import MemoryStore from "memorystore";
import { 
  loginSchema, 
  insertUserSchema,
  insertShiftSchema,
  insertVacationRequestSchema
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Session setup
  const SessionStore = MemoryStore(session);
  app.use(
    session({
      cookie: { maxAge: 86400000 }, // 24 hours
      store: new SessionStore({
        checkPeriod: 86400000, // prune expired entries every 24h
      }),
      resave: false,
      saveUninitialized: false,
      secret: process.env.SESSION_SECRET || "worktrack-secret",
    })
  );

  // Passport setup
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "Usuario no encontrado" });
        }
        if (user.password !== password) {
          return done(null, false, { message: "Contraseña incorrecta" });
        }
        return done(null, user);
      } catch (error) {
        return done(error);
      }
    })
  );

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Helper middleware for role-based access
  const requireAuth = (req: Request, res: Response, next: any) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "No autenticado" });
    }
    next();
  };

  const requireAdmin = (req: Request, res: Response, next: any) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "No autenticado" });
    }
    if ((req.user as any).role !== "admin") {
      return res.status(403).json({ message: "Acceso denegado" });
    }
    next();
  };

  // Helper for Zod validation
  const validateRequest = (schema: any) => (req: Request, res: Response, next: any) => {
    try {
      console.log("Validando datos:", JSON.stringify(req.body));
      schema.parse(req.body);
      console.log("Validación exitosa");
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        console.log("Error de validación Zod:", error);
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.log("Error de validación no Zod:", error);
      return res.status(400).json({ message: "Datos inválidos" });
    }
  };

  // Authentication routes
  app.post("/api/auth/login", validateRequest(loginSchema), (req, res, next) => {
    passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) {
        return next(err);
      }
      if (!user) {
        return res.status(401).json({ message: info.message });
      }
      req.logIn(user, (err) => {
        if (err) {
          return next(err);
        }
        return res.json({
          id: user.id,
          username: user.username,
          fullName: user.fullName,
          role: user.role,
        });
      });
    })(req, res, next);
  });

  app.post("/api/auth/logout", (req, res) => {
    req.logout(() => {
      res.json({ message: "Sesión cerrada correctamente" });
    });
  });

  app.get("/api/auth/current", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.json(null);
    }
    const user = req.user as any;
    return res.json({
      id: user.id,
      username: user.username,
      fullName: user.fullName,
      role: user.role,
    });
  });

  // User routes
  app.get("/api/users", requireAdmin, async (req, res) => {
    const users = await storage.getAllUsers();
    res.json(users);
  });

  app.post("/api/users", requireAdmin, validateRequest(insertUserSchema), async (req, res) => {
    try {
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(409).json({ message: "El nombre de usuario ya existe" });
      }
      const user = await storage.createUser(req.body);
      res.status(201).json(user);
    } catch (error) {
      res.status(500).json({ message: "Error al crear usuario" });
    }
  });

  app.patch("/api/users/:id", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.updateUser(userId, req.body);
      if (!user) {
        return res.status(404).json({ message: "Usuario no encontrado" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Error al actualizar usuario" });
    }
  });

  // Shift routes
  app.get("/api/shifts", requireAdmin, async (req, res) => {
    const shifts = await storage.getAllShifts();
    res.json(shifts);
  });

  app.get("/api/shifts/user/:userId", requireAuth, async (req, res) => {
    const userId = parseInt(req.params.userId);
    const currentUser = req.user as any;

    // Only admin can access other users' shifts
    if (currentUser.id !== userId && currentUser.role !== "admin") {
      return res.status(403).json({ message: "Acceso denegado" });
    }

    const shifts = await storage.getShiftsByUserId(userId);
    res.json(shifts);
  });

  app.get("/api/shifts/active/:userId", requireAuth, async (req, res) => {
    const userId = parseInt(req.params.userId);
    const currentUser = req.user as any;

    // Only admin can access other users' shifts
    if (currentUser.id !== userId && currentUser.role !== "admin") {
      return res.status(403).json({ message: "Acceso denegado" });
    }

    const shift = await storage.getActiveShiftByUserId(userId);
    res.json(shift || null);
  });

  app.post("/api/shifts", requireAuth, validateRequest(insertShiftSchema), async (req, res) => {
    try {
      const currentUser = req.user as any;
      
      // Employees can only create shifts for themselves
      if (currentUser.role !== "admin" && currentUser.id !== req.body.userId) {
        return res.status(403).json({ message: "Acceso denegado" });
      }
      
      // Check if there's already an active shift
      const activeShift = await storage.getActiveShiftByUserId(req.body.userId);
      if (activeShift) {
        return res.status(400).json({ message: "Ya hay una jornada activa" });
      }
      
      const shift = await storage.createShift(req.body);
      res.status(201).json(shift);
    } catch (error) {
      res.status(500).json({ message: "Error al crear jornada" });
    }
  });

  app.patch("/api/shifts/:id", requireAuth, async (req, res) => {
    try {
      const shiftId = parseInt(req.params.id);
      const currentUser = req.user as any;
      
      // Get the shift to check permissions
      const shift = await storage.getShiftById(shiftId);
      if (!shift) {
        return res.status(404).json({ message: "Jornada no encontrada" });
      }
      
      // Employees can only update their own shifts
      if (currentUser.role !== "admin" && currentUser.id !== shift.userId) {
        return res.status(403).json({ message: "Acceso denegado" });
      }
      
      const updatedShift = await storage.updateShift(shiftId, req.body);
      res.json(updatedShift);
    } catch (error) {
      res.status(500).json({ message: "Error al actualizar jornada" });
    }
  });

  // Vacation request routes
  app.get("/api/vacation-requests", requireAdmin, async (req, res) => {
    const requests = await storage.getAllVacationRequests();
    res.json(requests);
  });

  app.get("/api/vacation-requests/user/:userId", requireAuth, async (req, res) => {
    const userId = parseInt(req.params.userId);
    const currentUser = req.user as any;

    // Only admin can access other users' vacation requests
    if (currentUser.id !== userId && currentUser.role !== "admin") {
      return res.status(403).json({ message: "Acceso denegado" });
    }

    const requests = await storage.getVacationRequestsByUserId(userId);
    res.json(requests);
  });

  app.post("/api/vacation-requests", requireAuth, validateRequest(insertVacationRequestSchema), async (req, res) => {
    try {
      const currentUser = req.user as any;
      
      // Employees can only create vacation requests for themselves
      if (currentUser.role !== "admin" && currentUser.id !== req.body.userId) {
        return res.status(403).json({ message: "Acceso denegado" });
      }
      
      const request = await storage.createVacationRequest(req.body);
      res.status(201).json(request);
    } catch (error) {
      res.status(500).json({ message: "Error al crear solicitud de vacaciones" });
    }
  });

  app.patch("/api/vacation-requests/:id", requireAuth, async (req, res) => {
    try {
      const requestId = parseInt(req.params.id);
      const currentUser = req.user as any;
      
      // Get the request to check permissions
      const request = await storage.getVacationRequestById(requestId);
      if (!request) {
        return res.status(404).json({ message: "Solicitud no encontrada" });
      }
      
      // Only admin can approve/reject requests
      if (req.body.status && currentUser.role !== "admin") {
        return res.status(403).json({ message: "No autorizado para cambiar el estado" });
      }
      
      // Employees can only update their own requests
      if (currentUser.role !== "admin" && currentUser.id !== request.userId) {
        return res.status(403).json({ message: "Acceso denegado" });
      }
      
      const updatedRequest = await storage.updateVacationRequest(requestId, req.body);
      res.json(updatedRequest);
    } catch (error) {
      res.status(500).json({ message: "Error al actualizar solicitud" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
