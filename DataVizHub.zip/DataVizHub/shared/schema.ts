import { pgTable, text, serial, integer, boolean, timestamp, time, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email"),
  role: text("role").notNull().default("employee"),
  isActive: boolean("is_active").notNull().default(true),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  isActive: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Shift schema
export const shifts = pgTable("shifts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: timestamp("date").notNull(),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"),
  breakStartTime: timestamp("break_start_time"),
  breakEndTime: timestamp("break_end_time"),
  totalHours: time("total_hours"),
  hasIncident: boolean("has_incident").default(false),
  status: text("status").notNull().default("in_progress"),
  // Campos de geolocalización
  latitude: real("latitude"),
  longitude: real("longitude"),
  locationName: text("location_name"),
});

// Creamos un esquema modificado que acepte strings para los campos de fecha/hora
export const insertShiftSchema = z.object({
  userId: z.number(),
  date: z.string().or(z.date()),
  startTime: z.string().or(z.date()),
  endTime: z.string().or(z.date()).nullable().optional(),
  breakStartTime: z.string().or(z.date()).nullable().optional(),
  breakEndTime: z.string().or(z.date()).nullable().optional(),
  status: z.string().default("in_progress"),
  // Campos opcionales de geolocalización
  latitude: z.number().nullable().optional(),
  longitude: z.number().nullable().optional(),
  locationName: z.string().nullable().optional(),
});

export type InsertShift = z.infer<typeof insertShiftSchema>;
export type Shift = typeof shifts.$inferSelect;

// Vacation requests schema
export const vacationRequests = pgTable("vacation_requests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  comment: text("comment"),
  status: text("status").notNull().default("pending"),
  adminResponse: text("admin_response"),
  createdAt: timestamp("created_at").notNull(),
});

// Creamos un esquema para vacaciones que acepte strings para fechas
export const insertVacationRequestSchema = z.object({
  userId: z.number(),
  startDate: z.string().or(z.date()),
  endDate: z.string().or(z.date()),
  comment: z.string().nullable().optional(),
  createdAt: z.string().or(z.date()),
});

export type InsertVacationRequest = z.infer<typeof insertVacationRequestSchema>;
export type VacationRequest = typeof vacationRequests.$inferSelect;

// Extended schemas for forms
export const loginSchema = z.object({
  username: z.string().min(1, "Usuario es requerido"),
  password: z.string().min(1, "Contraseña es requerida"),
});

export type LoginForm = z.infer<typeof loginSchema>;

export const vacationRequestFormSchema = z.object({
  startDate: z.date({
    required_error: "Fecha de inicio es requerida",
  }),
  endDate: z.date({
    required_error: "Fecha de fin es requerida",
  }),
  comment: z.string().optional(),
}).refine(data => data.endDate >= data.startDate, {
  message: "La fecha de fin debe ser posterior a la fecha de inicio",
  path: ["endDate"],
});

export type VacationRequestForm = z.infer<typeof vacationRequestFormSchema>;
