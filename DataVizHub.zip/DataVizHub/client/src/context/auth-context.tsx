import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isValidUser } from "@/utils/auth-utils";

interface User {
  id: number;
  username: string;
  fullName: string;
  role: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<User | null>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: true,
  login: async () => null,
  logout: async () => {},
});

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  // Check if the user is already authenticated on mount
  useEffect(() => {
    async function checkAuth() {
      try {
        console.log("Checking authentication...");
        const response = await fetch("/api/auth/current", {
          credentials: "include",
        });
        
        console.log("Auth check response:", response.status);
        if (response.ok) {
          const userData = await response.json();
          console.log("User data:", userData);
          if (isValidUser(userData)) {
            setUser(userData);
          }
        }
      } catch (error) {
        console.error("Auth check error:", error);
      } finally {
        setIsLoading(false);
      }
    }
    
    checkAuth();
  }, []);
  
  const login = async (username: string, password: string): Promise<User | null> => {
    try {
      console.log("Attempting login with:", username);
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username, password }),
        credentials: "include",
      });
      
      console.log("Login response status:", response.status);
      
      if (!response.ok) {
        const errorData = await response.json();
        console.error("Login error data:", errorData);
        throw new Error(errorData.message || "Error de autenticación");
      }
      
      const userData = await response.json();
      console.log("Login successful, user data:", userData);
      setUser(userData);
      
      // Verificar que realmente se haya actualizado el estado después del inicio de sesión
      setTimeout(() => {
        fetch("/api/auth/current", {
          credentials: "include",
        })
        .then(res => res.json())
        .then(data => {
          console.log("Verification after login:", data);
          if (data && isValidUser(data)) {
            setUser(data);
          }
        })
        .catch(err => console.error("Verification error:", err));
      }, 500);
      
      return userData;
    } catch (error: any) {
      console.error("Login error:", error);
      throw new Error(error.message || "Error al iniciar sesión");
    }
  };
  
  const logout = async (): Promise<void> => {
    try {
      await apiRequest("POST", "/api/auth/logout", {});
      setUser(null);
    } catch (error) {
      console.error("Logout error:", error);
      toast({
        title: "Error",
        description: "Ha ocurrido un error al cerrar la sesión.",
        variant: "destructive",
      });
    }
  };
  
  return (
    <AuthContext.Provider value={{ user, isLoading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
