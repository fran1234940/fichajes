import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { LogOut, Clock } from "lucide-react";
import { useAuth } from "@/context/auth-context";
import { ClockDisplay } from "@/components/clock-display";
import { ShiftControls } from "@/components/shift-controls";
import { VacationRequestForm } from "@/components/vacation-request-form";
import { VacationHistory } from "@/components/vacation-history";
import { ShiftHistory } from "@/components/shift-history";

export default function EmployeeDashboard() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  const { data: activeShift, isLoading: isLoadingShift } = useQuery({
    queryKey: [`/api/shifts/active/${user?.id}`],
    enabled: !!user?.id,
  });

  const { data: shiftHistory, isLoading: isLoadingHistory } = useQuery({
    queryKey: [`/api/shifts/user/${user?.id}`],
    enabled: !!user?.id,
  });

  const { data: vacationRequests, isLoading: isLoadingVacations } = useQuery({
    queryKey: [`/api/vacation-requests/user/${user?.id}`],
    enabled: !!user?.id,
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <div className="bg-primary p-2 rounded-md mr-3 text-white">
              <Clock className="h-4 w-4" />
            </div>
            <h1 className="text-xl font-semibold text-gray-800">WorkTrack</h1>
          </div>
          <div className="flex items-center">
            <span className="text-sm text-gray-700 mr-4">{user?.fullName}</span>
            <Button variant="ghost" size="icon" onClick={handleLogout}>
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Time Tracking Card */}
          <div className="lg:col-span-2">
            <Card>
              <CardContent className="pt-6">
                <h2 className="text-lg font-semibold text-gray-800 mb-4">Control de Jornada</h2>
                
                <ClockDisplay activeShift={activeShift} isLoading={isLoadingShift} />
                
                <ShiftControls 
                  userId={user?.id}
                  activeShift={activeShift}
                  isLoading={isLoadingShift}
                />
              </CardContent>
            </Card>
          </div>
          
          {/* Vacation Request Card */}
          <div>
            <Card>
              <CardContent className="pt-6">
                <h2 className="text-lg font-semibold text-gray-800 mb-4">Solicitud de Vacaciones</h2>
                
                <VacationRequestForm userId={user?.id} />
                
                <div className="mt-6">
                  <h3 className="text-md font-medium text-gray-800 mb-3">Solicitudes recientes</h3>
                  <VacationHistory 
                    vacationRequests={vacationRequests || []} 
                    isLoading={isLoadingVacations}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Reports Card */}
          <div className="lg:col-span-3">
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-wrap justify-between items-center mb-6">
                  <h2 className="text-lg font-semibold text-gray-800">Historial de Fichajes</h2>
                  
                  <ShiftHistory 
                    shifts={shiftHistory || []} 
                    isLoading={isLoadingHistory} 
                    userId={user?.id} 
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
