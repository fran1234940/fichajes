import { z } from "zod";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useLocation } from "wouter";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { loginSchema, type LoginForm } from "@shared/schema";
import { useAuth } from "@/context/auth-context";
import { Clock } from "lucide-react";

export default function LoginPage() {
  const [loading, setLoading] = useState(false);
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { login, user } = useAuth();
  
  // Usamos useEffect para la redirección en lugar de una verificación condicional
  // Esto evita problemas con las reglas de hooks de React
  useEffect(() => {
    if (user) {
      console.log("User already logged in, redirecting to dashboard");
      window.location.href = user.role === "admin" ? "/admin" : "/employee";
    }
  }, [user]);

  const form = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "admin",
      password: "1234",
    },
  });

  const onSubmit = async (values: LoginForm) => {
    console.log("Form submitted with values:", values);
    setLoading(true);
    try {
      console.log("Attempting to login...");
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(values),
        credentials: "include",
      });
      
      console.log("Login response status:", response.status);
      
      if (!response.ok) {
        const errorData = await response.json();
        console.error("Login error data:", errorData);
        throw new Error(errorData.message || "Error de autenticación");
      }
      
      const userData = await response.json();
      console.log("Login successful, user data:", userData);
      
      // Redirect based on role
      window.location.href = userData.role === "admin" ? "/admin" : "/employee";
    } catch (error: any) {
      console.error("Login error:", error);
      toast({
        title: "Error de inicio de sesión",
        description: error.message || "Credenciales incorrectas",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gray-50">
      <div className="w-full max-w-md">
        <Card className="bg-white overflow-hidden">
          <CardContent className="pt-6 px-6 sm:px-8 pb-8">
            <div className="flex justify-center mb-6">
              <div className="bg-primary p-3 rounded-full text-white">
                <Clock className="h-6 w-6" />
              </div>
            </div>
            <h1 className="text-2xl font-semibold text-center text-gray-800 mb-8">WorkTrack</h1>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Usuario</FormLabel>
                      <FormControl>
                        <Input placeholder="Ingresa tu usuario" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Contraseña</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="Ingresa tu contraseña" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button type="submit" className="w-full mt-6" disabled={loading}>
                  {loading ? "Iniciando sesión..." : "Iniciar Sesión"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
