import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { LogOut, LayoutDashboard, Watch, Users, Calendar, BarChart } from "lucide-react";
import { useAuth } from "@/context/auth-context";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ShiftManagement } from "@/components/admin/shift-management";
import { UserManagement } from "@/components/admin/user-management";
import { VacationManagement } from "@/components/admin/vacation-management";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";

type Tab = "dashboard" | "shifts" | "users" | "vacations" | "reports";

export default function AdminDashboard() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState<Tab>("dashboard");
  const { toast } = useToast();
  const isMobile = useIsMobile();

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  const handleTabChange = (tab: Tab) => {
    setActiveTab(tab);
  };

  // Queries for summary data
  const { data: users = [], isError: usersError } = useQuery({
    queryKey: ["/api/users"],
    retry: 1,
  });
  
  const { data: shifts = [], isError: shiftsError } = useQuery({
    queryKey: ["/api/shifts"],
    retry: 1,
  });
  
  const { data: vacationRequests = [], isError: vacationsError } = useQuery({
    queryKey: ["/api/vacation-requests"],
    retry: 1,
  });

  // Log errors if any
  if (usersError) console.error("Error fetching users");
  if (shiftsError) console.error("Error fetching shifts");
  if (vacationsError) console.error("Error fetching vacation requests");

  // Calculate summary statistics
  const activeUsers = (users as any[]).filter((u) => u.isActive).length;
  const activeShifts = (shifts as any[]).filter((s) => s.status === "in_progress").length;
  const pendingRequests = (vacationRequests as any[]).filter((v) => v.status === "pending").length;
  const incidentsCount = (shifts as any[]).filter((s) => s.hasIncident).length;

  return (
    <div className="min-h-screen flex">
      {/* Sidebar Navigation */}
      <aside className="w-64 bg-gray-800 text-white h-screen sticky top-0 hidden md:block overflow-y-auto">
        <div className="p-4 flex items-center border-b border-gray-700">
          <div className="bg-primary p-2 rounded-md mr-3 text-white">
            <Clock className="h-5 w-5" />
          </div>
          <h1 className="text-xl font-semibold">WorkTrack</h1>
        </div>
        
        <nav className="mt-4">
          <ul>
            <li>
              <Button
                variant="ghost"
                className={cn(
                  "flex items-center w-full px-4 py-3 text-left rounded-none justify-start",
                  activeTab === "dashboard" 
                    ? "bg-gray-900 text-white" 
                    : "text-gray-300 hover:bg-gray-700"
                )}
                onClick={() => handleTabChange("dashboard")}
              >
                <LayoutDashboard className="h-5 w-5 mr-3" />
                <span>Dashboard</span>
              </Button>
            </li>
            <li>
              <Button
                variant="ghost"
                className={cn(
                  "flex items-center w-full px-4 py-3 text-left rounded-none justify-start",
                  activeTab === "shifts" 
                    ? "bg-gray-900 text-white" 
                    : "text-gray-300 hover:bg-gray-700"
                )}
                onClick={() => handleTabChange("shifts")}
              >
                <Watch className="h-5 w-5 mr-3" />
                <span>Gestión de Jornadas</span>
              </Button>
            </li>
            <li>
              <Button
                variant="ghost"
                className={cn(
                  "flex items-center w-full px-4 py-3 text-left rounded-none justify-start",
                  activeTab === "users" 
                    ? "bg-gray-900 text-white" 
                    : "text-gray-300 hover:bg-gray-700"
                )}
                onClick={() => handleTabChange("users")}
              >
                <Users className="h-5 w-5 mr-3" />
                <span>Gestión de Usuarios</span>
              </Button>
            </li>
            <li>
              <Button
                variant="ghost"
                className={cn(
                  "flex items-center w-full px-4 py-3 text-left rounded-none justify-start",
                  activeTab === "vacations" 
                    ? "bg-gray-900 text-white" 
                    : "text-gray-300 hover:bg-gray-700"
                )}
                onClick={() => handleTabChange("vacations")}
              >
                <Calendar className="h-5 w-5 mr-3" />
                <span>Gestión de Vacaciones</span>
              </Button>
            </li>
          </ul>
        </nav>
        
        <div className="absolute bottom-0 w-full border-t border-gray-700 p-4">
          <Button 
            variant="ghost" 
            className="flex items-center text-gray-300 hover:text-white w-full justify-start"
            onClick={handleLogout}
          >
            <LogOut className="h-5 w-5 mr-3" />
            <span>Cerrar Sesión</span>
          </Button>
        </div>
      </aside>
      
      {/* Mobile navigation */}
      {isMobile && (
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-gray-800 text-white z-10">
          <div className="flex justify-around">
            <Button
              variant="ghost"
              className={cn(
                "flex flex-col items-center py-2 px-3 text-xs",
                activeTab === "dashboard" ? "text-white" : "text-gray-300"
              )}
              onClick={() => handleTabChange("dashboard")}
            >
              <LayoutDashboard className="h-5 w-5 mb-1" />
              <span>Dashboard</span>
            </Button>
            
            <Button
              variant="ghost"
              className={cn(
                "flex flex-col items-center py-2 px-3 text-xs",
                activeTab === "shifts" ? "text-white" : "text-gray-300"
              )}
              onClick={() => handleTabChange("shifts")}
            >
              <Watch className="h-5 w-5 mb-1" />
              <span>Jornadas</span>
            </Button>
            
            <Button
              variant="ghost"
              className={cn(
                "flex flex-col items-center py-2 px-3 text-xs",
                activeTab === "users" ? "text-white" : "text-gray-300"
              )}
              onClick={() => handleTabChange("users")}
            >
              <Users className="h-5 w-5 mb-1" />
              <span>Usuarios</span>
            </Button>
            
            <Button
              variant="ghost"
              className={cn(
                "flex flex-col items-center py-2 px-3 text-xs",
                activeTab === "vacations" ? "text-white" : "text-gray-300"
              )}
              onClick={() => handleTabChange("vacations")}
            >
              <Calendar className="h-5 w-5 mb-1" />
              <span>Vacaciones</span>
            </Button>
            
            <Button
              variant="ghost"
              className="flex flex-col items-center py-2 px-3 text-gray-300 text-xs"
              onClick={handleLogout}
            >
              <LogOut className="h-5 w-5 mb-1" />
              <span>Salir</span>
            </Button>
          </div>
        </div>
      )}
      
      {/* Main Content */}
      <div className="flex-1 overflow-y-auto bg-gray-50 pb-16 md:pb-0">
        <header className="bg-white shadow-sm sticky top-0 z-10">
          <div className="px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
            <div className="flex items-center md:hidden">
              <div className="bg-primary text-white p-2 rounded-md mr-3">
                <Clock className="h-5 w-5" />
              </div>
              <h1 className="text-xl font-semibold text-gray-800">WorkTrack</h1>
            </div>
            <div className="hidden md:block">
              <h1 className="text-xl font-semibold text-gray-800">
                {activeTab === "dashboard" && "Dashboard"}
                {activeTab === "shifts" && "Gestión de Jornadas"}
                {activeTab === "users" && "Gestión de Usuarios"}
                {activeTab === "vacations" && "Gestión de Vacaciones"}
              </h1>
            </div>
            <div className="flex items-center">
              <span className="text-sm text-gray-700 mr-4">Administrador</span>
              <Button 
                variant="ghost" 
                size="icon" 
                className="md:hidden"
                onClick={handleLogout}
              >
                <LogOut className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </header>
        
        <main className="px-4 sm:px-6 lg:px-8 py-6">
          {activeTab === "dashboard" && (
            <>
              {/* Dashboard Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-blue-100 text-blue-600 mr-4">
                      <Users className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Usuarios Activos</p>
                      <p className="text-xl font-semibold">{activeUsers}</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-green-100 text-green-600 mr-4">
                      <Watch className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Jornadas Activas</p>
                      <p className="text-xl font-semibold">{activeShifts}</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-yellow-100 text-yellow-600 mr-4">
                      <Calendar className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Solicitudes Pendientes</p>
                      <p className="text-xl font-semibold">{pendingRequests}</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-red-100 text-red-600 mr-4">
                      <AlertTriangle className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Incidencias</p>
                      <p className="text-xl font-semibold">{incidentsCount}</p>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Show most recent data from each section */}
              <ShiftManagement previewMode />
              <div className="my-6"></div>
              <UserManagement previewMode />
              <div className="my-6"></div>
              <VacationManagement previewMode />
            </>
          )}
          
          {activeTab === "shifts" && <ShiftManagement />}
          {activeTab === "users" && <UserManagement />}
          {activeTab === "vacations" && <VacationManagement />}
        </main>
      </div>
    </div>
  );
}

function Clock(props: any) {
  return <LogOut {...props} />;
}

function AlertTriangle(props: any) {
  return <BarChart {...props} />;
}
