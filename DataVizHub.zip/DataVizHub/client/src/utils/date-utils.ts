import { format, differenceInDays, addDays } from "date-fns";
import { es } from "date-fns/locale";

/**
 * Format a date to a localized string
 */
export function formatDate(date: Date): string {
  return format(date, "d 'de' MMMM, yyyy", { locale: es });
}

/**
 * Format time to HH:MM:SS
 */
export function formatTime(date: Date): string {
  return format(date, "HH:mm:ss");
}

/**
 * Format time to HH:MM
 */
export function formatTimeShort(date: Date): string {
  return format(date, "HH:mm");
}

/**
 * Calculate the number of days between two dates (inclusive)
 */
export function getDaysBetweenDates(startDate: Date, endDate: Date): number {
  // Add 1 because differenceInDays is exclusive of the end date
  return differenceInDays(addDays(endDate, 1), startDate);
}

/**
 * Format a duration in seconds to HH:MM:SS
 */
export function formatDuration(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

/**
 * Format a break duration in minutes
 */
export function formatBreakDuration(minutes: number): string {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  
  if (hours > 0) {
    return `${hours}h ${mins}m`;
  }
  return `${mins}m`;
}
