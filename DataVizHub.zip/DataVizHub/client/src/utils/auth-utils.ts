/**
 * Check if a user object is valid and authenticated
 */
export function isValidUser(user: any): boolean {
  return user && typeof user === 'object' && user.id && user.username;
}

/**
 * Check if a user has admin role
 */
export function isAdmin(user: any): boolean {
  return isValidUser(user) && user.role === 'admin';
}

/**
 * Check if a user has employee role
 */
export function isEmployee(user: any): boolean {
  return isValidUser(user) && user.role === 'employee';
}

/**
 * Get the appropriate redirect path based on user role
 */
export function getRedirectPath(user: any): string {
  if (!isValidUser(user)) {
    return '/login';
  }
  
  return isAdmin(user) ? '/admin' : '/employee';
}
