import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { formatDate, formatTime } from "@/utils/date-utils";
import { Download } from "lucide-react";
import { PDFGenerator } from "@/components/pdf-generator";

interface ShiftHistoryProps {
  shifts: any[];
  isLoading: boolean;
  userId?: number;
}

export function ShiftHistory({ shifts, isLoading, userId }: ShiftHistoryProps) {
  const { toast } = useToast();
  const [generatingPDF, setGeneratingPDF] = useState(false);
  
  const handleDownloadPDF = async () => {
    if (!shifts || shifts.length === 0) {
      toast({
        title: "Error",
        description: "No hay datos para generar el PDF.",
        variant: "destructive",
      });
      return;
    }
    
    setGeneratingPDF(true);
    try {
      await PDFGenerator.generateShiftHistoryPDF(shifts, userId);
      toast({
        title: "PDF Generado",
        description: "El historial de fichajes se ha descargado correctamente.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Ha ocurrido un error al generar el PDF.",
        variant: "destructive",
      });
    } finally {
      setGeneratingPDF(false);
    }
  };
  
  // Sort shifts by date (most recent first)
  const sortedShifts = [...(shifts || [])].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );
  
  if (isLoading) {
    return (
      <div className="w-full">
        <div className="flex justify-between mb-4">
          <h2 className="text-lg font-semibold">Historial de Fichajes</h2>
          <Button variant="outline" disabled>
            <Download className="h-4 w-4 mr-2" /> Descargar PDF
          </Button>
        </div>
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }
  
  return (
    <div className="w-full">
      <div className="flex flex-wrap justify-between items-center mb-6">
        <h2 className="text-lg font-semibold text-gray-800">Historial de Fichajes</h2>
        <Button 
          variant="outline" 
          onClick={handleDownloadPDF}
          disabled={generatingPDF}
        >
          <Download className="h-4 w-4 mr-2" /> 
          {generatingPDF ? "Generando..." : "Descargar PDF"}
        </Button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Inicio</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fin</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Descanso</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Horas</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {sortedShifts.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-6 py-4 text-center text-sm text-gray-500">
                  No hay registros de fichajes.
                </td>
              </tr>
            ) : (
              sortedShifts.map((shift) => (
                <tr key={shift.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatDate(new Date(shift.date))}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {shift.startTime ? formatTime(new Date(shift.startTime)) : "--:--"}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {shift.endTime ? formatTime(new Date(shift.endTime)) : "--:--"}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {shift.breakStartTime && shift.breakEndTime 
                      ? calculateBreakDuration(new Date(shift.breakStartTime), new Date(shift.breakEndTime)) 
                      : "N/A"}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {shift.totalHours || "N/A"}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {shift.status === "in_progress" ? (
                      <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">
                        En Progreso
                      </Badge>
                    ) : shift.hasIncident ? (
                      <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">
                        Incidencia
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                        Normal
                      </Badge>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function calculateBreakDuration(start: Date, end: Date): string {
  const diffMs = end.getTime() - start.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const hours = Math.floor(diffMins / 60);
  const mins = diffMins % 60;
  
  if (hours > 0) {
    return `${hours}h ${mins}m`;
  }
  return `${mins}m`;
}
