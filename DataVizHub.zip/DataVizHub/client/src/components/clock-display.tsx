import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { formatTime, formatDate } from "@/utils/date-utils";

interface ClockDisplayProps {
  activeShift: any;
  isLoading: boolean;
}

export function ClockDisplay({ activeShift, isLoading }: ClockDisplayProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [workedSeconds, setWorkedSeconds] = useState(0);
  
  useEffect(() => {
    // Update current time every second
    const interval = setInterval(() => {
      setCurrentDate(new Date());
    }, 1000);
    
    return () => clearInterval(interval);
  }, []);
  
  useEffect(() => {
    if (!activeShift || activeShift.status !== "in_progress") {
      setWorkedSeconds(0);
      return;
    }
    
    // Calculate initial worked time
    let worked = 0;
    const startTime = new Date(activeShift.startTime);
    let lastBreakStart: Date | null = null;
    
    if (activeShift.breakStartTime && !activeShift.breakEndTime) {
      // If break is ongoing, count only time until break started
      lastBreakStart = new Date(activeShift.breakStartTime);
      worked = Math.floor((lastBreakStart.getTime() - startTime.getTime()) / 1000);
    } else if (activeShift.breakStartTime && activeShift.breakEndTime) {
      // If break is completed, need to account for break duration
      const breakStartTime = new Date(activeShift.breakStartTime);
      const breakEndTime = new Date(activeShift.breakEndTime);
      const breakDuration = Math.floor((breakEndTime.getTime() - breakStartTime.getTime()) / 1000);
      
      // Time from start until now, minus break duration
      worked = Math.floor((new Date().getTime() - startTime.getTime()) / 1000) - breakDuration;
    } else {
      // No breaks, simple calculation
      worked = Math.floor((new Date().getTime() - startTime.getTime()) / 1000);
    }
    
    setWorkedSeconds(worked > 0 ? worked : 0);
    
    // Update worked time counter
    const counter = setInterval(() => {
      if (lastBreakStart) {
        // Don't increment if on break
        return;
      }
      
      setWorkedSeconds(prevSeconds => prevSeconds + 1);
    }, 1000);
    
    return () => clearInterval(counter);
  }, [activeShift]);
  
  const formatWorkedTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  return (
    <div className="flex flex-wrap items-center mb-6 p-4 bg-gray-50 rounded-lg">
      <div className="flex-grow mb-3 md:mb-0">
        <div className="text-sm text-gray-500">Fecha actual</div>
        <div className="text-lg font-medium">
          {isLoading ? (
            <Skeleton className="h-7 w-36" />
          ) : (
            formatDate(currentDate)
          )}
        </div>
      </div>
      <div className="flex-grow mb-3 md:mb-0">
        <div className="text-sm text-gray-500">Hora actual</div>
        <div className="text-lg font-medium">
          {isLoading ? (
            <Skeleton className="h-7 w-24" />
          ) : (
            formatTime(currentDate)
          )}
        </div>
      </div>
      <div className="flex-grow">
        <div className="text-sm text-gray-500">Tiempo trabajado</div>
        <div className="text-lg font-medium">
          {isLoading ? (
            <Skeleton className="h-7 w-24" />
          ) : (
            formatWorkedTime(workedSeconds)
          )}
        </div>
      </div>
    </div>
  );
}
