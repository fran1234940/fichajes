import { jsPDF } from "jspdf";
import { User } from "@shared/schema";
import { formatDate, formatTime } from "@/utils/date-utils";

export class PDFGenerator {
  static async generateShiftHistoryPDF(shifts: any[], userId?: number, includeLocation: boolean = true) {
    try {
      // Create a new PDF document
      const doc = new jsPDF();
      
      // Add title and header
      doc.setFontSize(18);
      doc.text("WorkTrack - Historial de Fichajes", 14, 20);
      
      doc.setFontSize(12);
      doc.text(`Fecha de emisión: ${formatDate(new Date())}`, 14, 30);
      
      let userName = "";
      if (userId) {
        // Fetch user details if userId is provided
        try {
          const response = await fetch(`/api/users/${userId}`);
          if (response.ok) {
            const user = await response.json();
            userName = user.fullName;
            doc.text(`Usuario: ${user.fullName}`, 14, 40);
          }
        } catch (error) {
          doc.text(`Usuario ID: ${userId}`, 14, 40);
        }
      }
      
      // Create table headers with location if requested
      const headers = includeLocation 
        ? ["Fecha", "Inicio", "Fin", "Descanso", "Horas", "Ubicación", "Estado"]
        : ["Fecha", "Inicio", "Fin", "Descanso", "Horas", "Estado"];
      const tableData = [];
      
      // Sort shifts by date (most recent first)
      const sortedShifts = [...shifts].sort((a, b) => 
        new Date(b.date).getTime() - new Date(a.date).getTime()
      );
      
      // Process shift data
      for (const shift of sortedShifts) {
        const breakDuration = calculateBreakDuration(shift.breakStartTime, shift.breakEndTime);
        
        let status = "Normal";
        if (shift.status === "in_progress") {
          status = "En Progreso";
        } else if (shift.hasIncident) {
          status = "Incidencia";
        }
        
        tableData.push([
          formatDate(new Date(shift.date)),
          shift.startTime ? formatTime(new Date(shift.startTime)) : "--:--",
          shift.endTime ? formatTime(new Date(shift.endTime)) : "--:--",
          breakDuration,
          shift.totalHours || "N/A",
          status
        ]);
      }
      
      // Draw the table
      const startY = 50;
      const columnWidths = [30, 25, 25, 30, 25, 30];
      
      // Draw table headers
      doc.setFillColor(240, 240, 240);
      doc.rect(14, startY, doc.internal.pageSize.width - 28, 10, "F");
      doc.setFontSize(10);
      doc.setFont(undefined, 'bold');
      
      let xPos = 14;
      headers.forEach((header, i) => {
        doc.text(header, xPos + 2, startY + 7);
        xPos += columnWidths[i];
      });
      
      // Draw table data
      doc.setFont(undefined, 'normal');
      let yPos = startY + 10;
      
      tableData.forEach((row, rowIndex) => {
        // Add page if reaching end of page
        if (yPos > doc.internal.pageSize.height - 20) {
          doc.addPage();
          doc.setFontSize(10);
          yPos = 20;
        }
        
        // Draw alternating row backgrounds
        if (rowIndex % 2 === 1) {
          doc.setFillColor(250, 250, 250);
          doc.rect(14, yPos, doc.internal.pageSize.width - 28, 10, "F");
        }
        
        // Draw special background for incidents
        if (row[5] === "Incidencia") {
          doc.setFillColor(254, 242, 242);
          doc.rect(14, yPos, doc.internal.pageSize.width - 28, 10, "F");
        }
        
        // Draw row data
        xPos = 14;
        row.forEach((cell: string, i: number) => {
          doc.text(cell, xPos + 2, yPos + 7);
          xPos += columnWidths[i];
        });
        
        yPos += 10;
      });
      
      // Draw table border
      doc.setLineWidth(0.1);
      doc.rect(
        14, 
        startY, 
        doc.internal.pageSize.width - 28, 
        yPos - startY, 
        "S"
      );
      
      // Add footer
      const pageCount = doc.internal.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.text(
          `Página ${i} de ${pageCount} - Generado por WorkTrack`,
          14,
          doc.internal.pageSize.height - 10
        );
      }
      
      // Save the PDF
      doc.save(`worktrack_fichajes_${new Date().toISOString().split('T')[0]}.pdf`);
      
      return true;
    } catch (error) {
      console.error("Error generating PDF:", error);
      throw new Error("Error al generar el PDF");
    }
  }
}

function calculateBreakDuration(breakStartTime: string | null, breakEndTime: string | null): string {
  if (!breakStartTime || !breakEndTime) return "N/A";
  
  const start = new Date(breakStartTime);
  const end = new Date(breakEndTime);
  const diffMs = end.getTime() - start.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const hours = Math.floor(diffMins / 60);
  const mins = diffMins % 60;
  
  if (hours > 0) {
    return `${hours}h ${mins}m`;
  }
  return `${mins}m`;
}
