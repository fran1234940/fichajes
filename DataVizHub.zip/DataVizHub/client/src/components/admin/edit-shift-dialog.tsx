import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

interface EditShiftDialogProps {
  isOpen: boolean;
  onClose: () => void;
  shift: any;
  users: any[];
}

const editShiftSchema = z.object({
  date: z.string().min(1, "La fecha es requerida"),
  startTime: z.string().min(1, "La hora de inicio es requerida"),
  endTime: z.string().optional(),
  breakStartTime: z.string().optional(),
  breakEndTime: z.string().optional(),
}).refine((data) => {
  // If breakEndTime exists, breakStartTime must also exist
  if (data.breakEndTime && !data.breakStartTime) {
    return false;
  }
  
  // If both break times exist, breakStartTime must be before breakEndTime
  if (data.breakStartTime && data.breakEndTime) {
    return new Date(data.breakStartTime) < new Date(data.breakEndTime);
  }
  
  // If endTime exists, it must be after startTime
  if (data.endTime) {
    return new Date(data.startTime) < new Date(data.endTime);
  }
  
  return true;
}, {
  message: "Las horas no son válidas. Verifica que la secuencia de tiempos sea correcta.",
  path: ["breakEndTime"],
});

type FormValues = z.infer<typeof editShiftSchema>;

export function EditShiftDialog({ isOpen, onClose, shift, users }: EditShiftDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const formatDateTimeForInput = (dateTimeString: string | null | undefined) => {
    if (!dateTimeString) return "";
    const date = new Date(dateTimeString);
    return date.toISOString().slice(0, 16); // Format: YYYY-MM-DDThh:mm
  };
  
  const form = useForm<FormValues>({
    resolver: zodResolver(editShiftSchema),
    defaultValues: {
      date: shift ? formatDateTimeForInput(shift.date).split("T")[0] : "",
      startTime: shift ? formatDateTimeForInput(shift.startTime) : "",
      endTime: shift?.endTime ? formatDateTimeForInput(shift.endTime) : "",
      breakStartTime: shift?.breakStartTime ? formatDateTimeForInput(shift.breakStartTime) : "",
      breakEndTime: shift?.breakEndTime ? formatDateTimeForInput(shift.breakEndTime) : "",
    },
  });
  
  // Update form values when shift changes
  useState(() => {
    if (shift) {
      form.reset({
        date: formatDateTimeForInput(shift.date).split("T")[0],
        startTime: formatDateTimeForInput(shift.startTime),
        endTime: shift.endTime ? formatDateTimeForInput(shift.endTime) : "",
        breakStartTime: shift.breakStartTime ? formatDateTimeForInput(shift.breakStartTime) : "",
        breakEndTime: shift.breakEndTime ? formatDateTimeForInput(shift.breakEndTime) : "",
      });
    }
  });
  
  const mutation = useMutation({
    mutationFn: async (values: FormValues) => {
      if (!shift) return null;
      
      // Prepare data for API
      const data: any = {};
      const dateStr = values.date;
      
      if (values.startTime) {
        data.startTime = new Date(values.startTime).toISOString();
      }
      
      if (values.endTime) {
        data.endTime = new Date(values.endTime).toISOString();
      }
      
      if (values.breakStartTime) {
        data.breakStartTime = new Date(values.breakStartTime).toISOString();
      }
      
      if (values.breakEndTime) {
        data.breakEndTime = new Date(values.breakEndTime).toISOString();
      }
      
      const res = await apiRequest("PATCH", `/api/shifts/${shift.id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shifts"] });
      queryClient.invalidateQueries({ queryKey: [`/api/shifts/user/${shift.userId}`] });
      toast({
        title: "Jornada Actualizada",
        description: "La jornada ha sido actualizada correctamente.",
      });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Ha ocurrido un error al actualizar la jornada.",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsSubmitting(false);
    }
  });
  
  const onSubmit = async (values: FormValues) => {
    setIsSubmitting(true);
    mutation.mutate(values);
  };
  
  const getUserName = (userId: number) => {
    const user = users.find((u: any) => u.id === userId);
    return user ? user.fullName : `Usuario ${userId}`;
  };
  
  if (!shift) return null;
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[550px]">
        <DialogHeader>
          <DialogTitle>Editar Jornada</DialogTitle>
        </DialogHeader>
        
        <div className="text-sm text-gray-500 mb-4">
          <p>Usuario: <span className="font-medium text-gray-700">{getUserName(shift.userId)}</span></p>
          <p>Fecha: <span className="font-medium text-gray-700">{new Date(shift.date).toLocaleDateString()}</span></p>
        </div>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="startTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Hora de Inicio</FormLabel>
                    <FormControl>
                      <Input type="datetime-local" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="endTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Hora de Fin</FormLabel>
                    <FormControl>
                      <Input 
                        type="datetime-local" 
                        {...field} 
                        value={field.value || ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="breakStartTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Inicio de Descanso</FormLabel>
                    <FormControl>
                      <Input 
                        type="datetime-local" 
                        {...field} 
                        value={field.value || ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="breakEndTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Fin de Descanso</FormLabel>
                    <FormControl>
                      <Input 
                        type="datetime-local" 
                        {...field} 
                        value={field.value || ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <DialogFooter className="mt-6">
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose}
                disabled={isSubmitting}
              >
                Cancelar
              </Button>
              <Button 
                type="submit" 
                disabled={isSubmitting}
              >
                {isSubmitting ? "Guardando..." : "Guardar Cambios"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
