import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatDate, formatTime } from "@/utils/date-utils";
import { ConfirmationDialog } from "@/components/confirmation-dialog";
import { EditShiftDialog } from "@/components/admin/edit-shift-dialog";
import { Filter, Edit, RefreshCw } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface ShiftManagementProps {
  previewMode?: boolean;
}

export function ShiftManagement({ previewMode = false }: ShiftManagementProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedUserId, setSelectedUserId] = useState<string>("");
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [showIncidentsOnly, setShowIncidentsOnly] = useState<boolean>(false);
  const [isResetDialogOpen, setIsResetDialogOpen] = useState<boolean>(false);
  const [shiftToReset, setShiftToReset] = useState<number | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState<boolean>(false);
  const [shiftToEdit, setShiftToEdit] = useState<any | null>(null);
  
  const { data: shifts = [], isLoading: isLoadingShifts } = useQuery<any[]>({
    queryKey: ["/api/shifts"],
  });
  
  const { data: users = [], isLoading: isLoadingUsers } = useQuery<any[]>({
    queryKey: ["/api/users"],
  });
  
  const resetShiftMutation = useMutation({
    mutationFn: async (shiftId: number) => {
      const res = await apiRequest("PATCH", `/api/shifts/${shiftId}`, {
        endTime: null,
        breakStartTime: null,
        breakEndTime: null,
        totalHours: null,
        hasIncident: false,
        status: "in_progress"
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shifts"] });
      toast({
        title: "Jornada Restablecida",
        description: "La jornada ha sido restablecida correctamente.",
      });
      setShiftToReset(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Ha ocurrido un error al restablecer la jornada.",
        variant: "destructive",
      });
    }
  });
  
  const handleResetShift = (shiftId: number) => {
    setShiftToReset(shiftId);
    setIsResetDialogOpen(true);
  };
  
  const confirmResetShift = () => {
    if (shiftToReset) {
      resetShiftMutation.mutate(shiftToReset);
    }
    setIsResetDialogOpen(false);
  };
  
  const handleEditShift = (shift: any) => {
    setShiftToEdit(shift);
    setIsEditDialogOpen(true);
  };
  
  // Filter shifts based on selected filters
  const filteredShifts = shifts.filter((shift: any) => {
    let matched = true;
    
    if (selectedUserId) {
      matched = matched && shift.userId === parseInt(selectedUserId);
    }
    
    if (selectedDate) {
      const shiftDate = new Date(shift.date).toISOString().split('T')[0];
      matched = matched && shiftDate === selectedDate;
    }
    
    if (showIncidentsOnly) {
      matched = matched && shift.hasIncident;
    }
    
    return matched;
  });
  
  // Sort shifts by date (most recent first)
  const sortedShifts = [...filteredShifts].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );
  
  // For preview mode, only show the most recent 3 shifts
  const displayShifts = previewMode ? sortedShifts.slice(0, 3) : sortedShifts;
  
  const getUserName = (userId: number) => {
    const user = users.find((u: any) => u.id === userId);
    return user ? user.fullName : `Usuario ${userId}`;
  };
  
  // Calculate break duration
  const getBreakDuration = (breakStartTime: string, breakEndTime: string) => {
    if (!breakStartTime || !breakEndTime) return "N/A";
    
    const start = new Date(breakStartTime);
    const end = new Date(breakEndTime);
    const diffMs = end.getTime() - start.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const hours = Math.floor(diffMins / 60);
    const mins = diffMins % 60;
    
    if (hours > 0) {
      return `${hours}h ${mins}m`;
    }
    return `${mins}m`;
  };
  
  if (isLoadingShifts || isLoadingUsers) {
    return (
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold text-gray-800">Gestión de Jornadas</h2>
        </div>
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }
  
  return (
    <div className="mb-8">
      <div className="flex flex-wrap justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-gray-800">
          {previewMode ? "Jornadas Recientes" : "Gestión de Jornadas"}
        </h2>
        
        {!previewMode && (
          <div className="mt-2 sm:mt-0 flex flex-wrap gap-2">
            <Select 
              value={selectedUserId || "none"} 
              onValueChange={(value) => setSelectedUserId(value === "none" ? "" : value)}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Todos los usuarios" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Todos los usuarios</SelectItem>
                {users.map((user: any) => (
                  <SelectItem key={user.id} value={user.id.toString()}>
                    {user.fullName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-auto"
            />
            
            <Button
              variant={showIncidentsOnly ? "default" : "outline"}
              onClick={() => setShowIncidentsOnly(!showIncidentsOnly)}
            >
              <Filter className="h-4 w-4 mr-2" /> 
              {showIncidentsOnly ? "Mostrar Todos" : "Solo Incidencias"}
            </Button>
          </div>
        )}
      </div>
      
      <Card className="bg-white shadow-sm">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Usuario</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Inicio</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fin</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Descanso</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Horas</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {displayShifts.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="px-6 py-4 text-center text-sm text-gray-500">
                      No hay jornadas que coincidan con los filtros seleccionados.
                    </td>
                  </tr>
                ) : (
                  displayShifts.map((shift: any) => (
                    <tr 
                      key={shift.id} 
                      className={shift.hasIncident ? "bg-red-50" : ""}
                    >
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="text-sm font-medium text-gray-900">
                            {getUserName(shift.userId)}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {formatDate(new Date(shift.date))}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {shift.startTime ? formatTime(new Date(shift.startTime)) : "--:--"}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {shift.endTime ? formatTime(new Date(shift.endTime)) : "--:--"}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {getBreakDuration(shift.breakStartTime, shift.breakEndTime)}
                      </td>
                      <td className={`px-6 py-4 whitespace-nowrap text-sm ${shift.hasIncident ? "text-red-500 font-medium" : "text-gray-500"}`}>
                        {shift.totalHours || "N/A"}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {shift.status === "in_progress" ? (
                          <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">
                            En Progreso
                          </Badge>
                        ) : shift.hasIncident ? (
                          <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">
                            Incidencia
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                            Normal
                          </Badge>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-primary hover:text-primary/80 mr-2"
                          onClick={() => handleEditShift(shift)}
                        >
                          <Edit className="h-4 w-4 mr-1" /> Editar
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-red-600 hover:text-red-700"
                          onClick={() => handleResetShift(shift.id)}
                        >
                          <RefreshCw className="h-4 w-4 mr-1" /> Reset
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          
          {!previewMode && displayShifts.length > 0 && (
            <div className="bg-gray-50 px-4 py-3 border-t border-gray-200 sm:px-6">
              <div className="flex justify-between items-center">
                <div className="text-sm text-gray-700">
                  Mostrando <span className="font-medium">{displayShifts.length}</span> de <span className="font-medium">{filteredShifts.length}</span> jornadas
                </div>
              </div>
            </div>
          )}
          
          {previewMode && shifts.length > 3 && (
            <div className="bg-gray-50 px-4 py-3 border-t border-gray-200 sm:px-6">
              <Button variant="link" className="mx-auto block text-primary">
                Ver todas las jornadas
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Confirmation dialog for reset */}
      <ConfirmationDialog
        isOpen={isResetDialogOpen}
        onClose={() => setIsResetDialogOpen(false)}
        onConfirm={confirmResetShift}
        title="Restablecer Jornada"
        message="¿Estás seguro de que deseas restablecer esta jornada? Esta acción no se puede deshacer."
      />
      
      {/* Edit shift dialog */}
      <EditShiftDialog
        isOpen={isEditDialogOpen}
        onClose={() => setIsEditDialogOpen(false)}
        shift={shiftToEdit}
        users={users}
      />
    </div>
  );
}
