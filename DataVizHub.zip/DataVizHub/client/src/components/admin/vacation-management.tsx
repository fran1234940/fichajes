import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatDate, getDaysBetweenDates } from "@/utils/date-utils";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Check, X } from "lucide-react";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

interface VacationManagementProps {
  previewMode?: boolean;
}

export function VacationManagement({ previewMode = false }: VacationManagementProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [userFilter, setUserFilter] = useState<string>("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [responseType, setResponseType] = useState<"approve" | "reject">("approve");
  const [selectedRequest, setSelectedRequest] = useState<any>(null);
  
  const { data: vacationRequests = [], isLoading: isLoadingRequests } = useQuery<any[]>({
    queryKey: ["/api/vacation-requests"],
  });
  
  const { data: users = [], isLoading: isLoadingUsers } = useQuery<any[]>({
    queryKey: ["/api/users"],
  });
  
  const responseSchema = z.object({
    adminResponse: z.string().min(1, "La respuesta es requerida")
  });
  
  const form = useForm({
    resolver: zodResolver(responseSchema),
    defaultValues: {
      adminResponse: "",
    }
  });
  
  const updateRequestMutation = useMutation({
    mutationFn: async ({ id, status, adminResponse }: any) => {
      const res = await apiRequest("PATCH", `/api/vacation-requests/${id}`, {
        status,
        adminResponse
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/vacation-requests"] });
      toast({
        title: "Solicitud Actualizada",
        description: `La solicitud de vacaciones ha sido ${responseType === "approve" ? "aprobada" : "rechazada"} correctamente.`,
      });
      setDialogOpen(false);
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Ha ocurrido un error al actualizar la solicitud.",
        variant: "destructive",
      });
    }
  });
  
  // Filter vacation requests based on selected filters
  const filteredRequests = vacationRequests.filter((request: any) => {
    let matched = true;
    
    if (statusFilter) {
      matched = matched && request.status === statusFilter;
    }
    
    if (userFilter) {
      matched = matched && request.userId === parseInt(userFilter);
    }
    
    return matched;
  });
  
  // Sort requests by date (most recent first)
  const sortedRequests = [...filteredRequests].sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
  
  // For preview mode, only show pending requests and limit to 3
  const displayRequests = previewMode 
    ? sortedRequests.filter((r: any) => r.status === "pending").slice(0, 3) 
    : sortedRequests;
  
  const getUserName = (userId: number) => {
    const user = users.find((u: any) => u.id === userId);
    return user ? user.fullName : `Usuario ${userId}`;
  };
  
  const handleRespondToRequest = (request: any, type: "approve" | "reject") => {
    setSelectedRequest(request);
    setResponseType(type);
    setDialogOpen(true);
  };
  
  const onSubmitResponse = (values: any) => {
    if (!selectedRequest) return;
    
    updateRequestMutation.mutate({
      id: selectedRequest.id,
      status: responseType === "approve" ? "approved" : "rejected",
      adminResponse: values.adminResponse
    });
  };
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">
            Pendiente
          </Badge>
        );
      case "approved":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
            Aprobada
          </Badge>
        );
      case "rejected":
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">
            Rechazada
          </Badge>
        );
      default:
        return (
          <Badge variant="outline" className="bg-gray-100 text-gray-800 border-gray-200">
            {status}
          </Badge>
        );
    }
  };
  
  if (isLoadingRequests || isLoadingUsers) {
    return (
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold text-gray-800">Gestión de Vacaciones</h2>
        </div>
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }
  
  return (
    <div className="mb-8">
      <div className="flex flex-wrap justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-gray-800">
          {previewMode ? "Solicitudes de Vacaciones Pendientes" : "Gestión de Vacaciones"}
        </h2>
        
        {!previewMode && (
          <div className="flex flex-wrap gap-2">
            <Select 
              value={statusFilter || "none"} 
              onValueChange={(value) => setStatusFilter(value === "none" ? "" : value)}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Todos los estados" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Todos los estados</SelectItem>
                <SelectItem value="pending">Pendiente</SelectItem>
                <SelectItem value="approved">Aprobado</SelectItem>
                <SelectItem value="rejected">Rechazado</SelectItem>
              </SelectContent>
            </Select>
            
            <Select 
              value={userFilter || "none"} 
              onValueChange={(value) => setUserFilter(value === "none" ? "" : value)}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Todos los usuarios" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Todos los usuarios</SelectItem>
                {users.map((user: any) => (
                  <SelectItem key={user.id} value={user.id.toString()}>
                    {user.fullName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
      </div>
      
      <Card className="bg-white shadow-sm">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Usuario</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fechas</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Días</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Comentario</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {displayRequests.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-4 text-center text-sm text-gray-500">
                      No hay solicitudes de vacaciones que coincidan con los filtros seleccionados.
                    </td>
                  </tr>
                ) : (
                  displayRequests.map((request: any) => (
                    <tr key={request.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="text-sm font-medium text-gray-900">
                            {getUserName(request.userId)}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {formatDate(new Date(request.startDate))} - {formatDate(new Date(request.endDate))}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {getDaysBetweenDates(new Date(request.startDate), new Date(request.endDate))}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">
                        {request.comment || "N/A"}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {getStatusBadge(request.status)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        {request.status === "pending" ? (
                          <>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="text-green-600 hover:text-green-700 mr-2"
                              onClick={() => handleRespondToRequest(request, "approve")}
                              disabled={previewMode}
                            >
                              <Check className="h-4 w-4 mr-1" /> Aprobar
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="text-red-600 hover:text-red-700"
                              onClick={() => handleRespondToRequest(request, "reject")}
                              disabled={previewMode}
                            >
                              <X className="h-4 w-4 mr-1" /> Rechazar
                            </Button>
                          </>
                        ) : (
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="text-gray-600 hover:text-gray-700"
                            onClick={() => {}}
                            disabled={previewMode}
                          >
                            Ver detalles
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          
          {previewMode && vacationRequests.filter((r: any) => r.status === "pending").length > 3 && (
            <div className="bg-gray-50 px-4 py-3 border-t border-gray-200 sm:px-6">
              <Button variant="link" className="mx-auto block text-primary">
                Ver todas las solicitudes
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
      
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {responseType === "approve" ? "Aprobar Solicitud" : "Rechazar Solicitud"}
            </DialogTitle>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmitResponse)} className="space-y-4">
              <FormField
                control={form.control}
                name="adminResponse"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Respuesta</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Escribe una respuesta para el empleado..." 
                        {...field} 
                        rows={4}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setDialogOpen(false)}
                >
                  Cancelar
                </Button>
                <Button 
                  type="submit" 
                  variant={responseType === "approve" ? "default" : "destructive"}
                  disabled={updateRequestMutation.isPending}
                >
                  {updateRequestMutation.isPending ? "Procesando..." : responseType === "approve" ? "Aprobar" : "Rechazar"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
