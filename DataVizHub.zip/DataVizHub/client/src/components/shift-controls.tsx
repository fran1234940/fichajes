import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatTime } from "@/utils/date-utils";
import { Play, Coffee, Check, StopCircle } from "lucide-react";
import { ConfirmationDialog } from "@/components/confirmation-dialog";

interface ShiftControlsProps {
  userId?: number;
  activeShift: any;
  isLoading: boolean;
}

export function ShiftControls({ userId, activeShift, isLoading }: ShiftControlsProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [confirmAction, setConfirmAction] = useState<string>("");
  const [confirmTitle, setConfirmTitle] = useState<string>("");
  const [confirmMessage, setConfirmMessage] = useState<string>("");
  
  const [geoLoading, setGeoLoading] = useState(false);
  const [geoError, setGeoError] = useState<string | null>(null);
  
  const startShiftMutation = useMutation({
    mutationFn: async () => {
      // Creamos los objetos Date directamente
      const now = new Date();
      let geoData = {};
      
      setGeoLoading(true);
      setGeoError(null);
      
      // Intentamos obtener la geolocalización
      try {
        if (navigator.geolocation) {
          const position = await new Promise<GeolocationPosition>((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(resolve, reject, {
              enableHighAccuracy: true,
              timeout: 5000,
              maximumAge: 0
            });
          });
          
          const { latitude, longitude } = position.coords;
          
          // Intentamos obtener el nombre de la ubicación mediante la API de geocodificación inversa
          try {
            const response = await fetch(
              `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`,
              { headers: { "Accept-Language": "es" } }
            );
            const locationData = await response.json();
            const locationName = locationData.display_name || "Ubicación desconocida";
            
            geoData = { latitude, longitude, locationName };
          } catch (err) {
            // Si falla la geocodificación inversa, aún guardamos las coordenadas
            geoData = { latitude, longitude };
          }
        }
      } catch (err: any) {
        console.error("Error al obtener geolocalización:", err);
        setGeoError(err.message || "No se pudo obtener la ubicación");
      } finally {
        setGeoLoading(false);
      }
      
      const data = {
        userId,
        date: now,
        startTime: now,
        status: "in_progress",
        ...geoData
      };
      
      console.log("Enviando datos para iniciar jornada:", JSON.stringify(data));
      
      try {
        const res = await apiRequest("POST", "/api/shifts", data);
        const responseData = await res.json();
        console.log("Respuesta del servidor:", responseData);
        return responseData;
      } catch (error) {
        console.error("Error al enviar datos:", error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/shifts/active/${userId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/shifts/user/${userId}`] });
      toast({
        title: "Jornada Iniciada",
        description: "Se ha registrado el inicio de jornada correctamente.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Ha ocurrido un error al iniciar la jornada.",
        variant: "destructive",
      });
    }
  });
  
  const updateShiftMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("PATCH", `/api/shifts/${activeShift.id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/shifts/active/${userId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/shifts/user/${userId}`] });
      
      let successMessage = "";
      if (confirmAction === "startBreak") {
        successMessage = "Se ha registrado el inicio del descanso correctamente.";
      } else if (confirmAction === "endBreak") {
        successMessage = "Se ha registrado el fin del descanso correctamente.";
      } else if (confirmAction === "endShift") {
        successMessage = "Se ha registrado el fin de la jornada correctamente.";
      }
      
      toast({
        title: "Acción Completada",
        description: successMessage,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Ha ocurrido un error al actualizar la jornada.",
        variant: "destructive",
      });
    }
  });
  
  const handleStartShift = () => {
    setConfirmTitle("Iniciar Jornada");
    setConfirmMessage("¿Estás seguro de que deseas iniciar tu jornada laboral?");
    setConfirmAction("startShift");
    setIsConfirmOpen(true);
  };
  
  const handleStartBreak = () => {
    setConfirmTitle("Iniciar Descanso");
    setConfirmMessage("¿Estás seguro de que deseas iniciar tu descanso?");
    setConfirmAction("startBreak");
    setIsConfirmOpen(true);
  };
  
  const handleEndBreak = () => {
    setConfirmTitle("Finalizar Descanso");
    setConfirmMessage("¿Estás seguro de que deseas finalizar tu descanso?");
    setConfirmAction("endBreak");
    setIsConfirmOpen(true);
  };
  
  const handleEndShift = () => {
    setConfirmTitle("Finalizar Jornada");
    setConfirmMessage("¿Estás seguro de que deseas finalizar tu jornada laboral?");
    setConfirmAction("endShift");
    setIsConfirmOpen(true);
  };
  
  const handleConfirm = () => {
    const now = new Date();
    
    if (confirmAction === "startShift") {
      startShiftMutation.mutate();
    } else if (confirmAction === "startBreak") {
      updateShiftMutation.mutate({ breakStartTime: now });
    } else if (confirmAction === "endBreak") {
      updateShiftMutation.mutate({ breakEndTime: now });
    } else if (confirmAction === "endShift") {
      updateShiftMutation.mutate({ 
        endTime: now,
        status: "completed"
      });
    }
    
    setIsConfirmOpen(false);
  };
  
  // Determine which buttons to show based on shift status
  const showStartShift = !activeShift || activeShift.status !== "in_progress";
  const showStartBreak = activeShift && activeShift.status === "in_progress" && !activeShift.breakStartTime;
  const showEndBreak = activeShift && activeShift.status === "in_progress" && activeShift.breakStartTime && !activeShift.breakEndTime;
  const showEndShift = activeShift && activeShift.status === "in_progress" && (!activeShift.breakStartTime || activeShift.breakEndTime);
  
  const isLoading2 = isLoading || startShiftMutation.isPending || updateShiftMutation.isPending;
  
  return (
    <>
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4">
          {isLoading2 ? (
            <>
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-full" />
            </>
          ) : (
            <>
              {showStartShift && (
                <div>
                  <Button 
                    className="w-full bg-primary hover:bg-primary/90 text-white font-medium py-3 px-4"
                    onClick={handleStartShift}
                  >
                    <Play className="h-4 w-4 mr-2" /> Iniciar Jornada
                  </Button>
                </div>
              )}
              
              {showStartBreak && (
                <div>
                  <Button 
                    className="w-full bg-amber-500 hover:bg-amber-600 text-white font-medium py-3 px-4"
                    onClick={handleStartBreak}
                  >
                    <Coffee className="h-4 w-4 mr-2" /> Iniciar Descanso
                  </Button>
                </div>
              )}
              
              {showEndBreak && (
                <div>
                  <Button 
                    className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-medium py-3 px-4"
                    onClick={handleEndBreak}
                  >
                    <Check className="h-4 w-4 mr-2" /> Finalizar Descanso
                  </Button>
                </div>
              )}
              
              {showEndShift && (
                <div>
                  <Button 
                    className="w-full bg-indigo-500 hover:bg-indigo-600 text-white font-medium py-3 px-4"
                    onClick={handleEndShift}
                  >
                    <StopCircle className="h-4 w-4 mr-2" /> Finalizar Jornada
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
        
        {/* Time Tracking Details */}
        <div className="border-t border-gray-200 px-4 py-5 sm:p-6">
          <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
            <div>
              <dt className="text-sm font-medium text-gray-500">Inicio de jornada</dt>
              <dd className="mt-1 text-sm text-gray-900">
                {isLoading2 ? (
                  <Skeleton className="h-5 w-24" />
                ) : (
                  activeShift?.startTime ? formatTime(new Date(activeShift.startTime)) : "--:--:--"
                )}
              </dd>
            </div>
            
            <div>
              <dt className="text-sm font-medium text-gray-500">Fin de jornada</dt>
              <dd className="mt-1 text-sm text-gray-900">
                {isLoading2 ? (
                  <Skeleton className="h-5 w-24" />
                ) : (
                  activeShift?.endTime ? formatTime(new Date(activeShift.endTime)) : "--:--:--"
                )}
              </dd>
            </div>
            
            <div>
              <dt className="text-sm font-medium text-gray-500">Inicio de descanso</dt>
              <dd className="mt-1 text-sm text-gray-900">
                {isLoading2 ? (
                  <Skeleton className="h-5 w-24" />
                ) : (
                  activeShift?.breakStartTime ? formatTime(new Date(activeShift.breakStartTime)) : "--:--:--"
                )}
              </dd>
            </div>
            
            <div>
              <dt className="text-sm font-medium text-gray-500">Fin de descanso</dt>
              <dd className="mt-1 text-sm text-gray-900">
                {isLoading2 ? (
                  <Skeleton className="h-5 w-24" />
                ) : (
                  activeShift?.breakEndTime ? formatTime(new Date(activeShift.breakEndTime)) : "--:--:--"
                )}
              </dd>
            </div>
            
            {activeShift?.locationName && (
              <div className="sm:col-span-2">
                <dt className="text-sm font-medium text-gray-500">Ubicación</dt>
                <dd className="mt-1 text-sm text-gray-900">
                  {activeShift.locationName}
                </dd>
              </div>
            )}
            
            {geoError && (
              <div className="sm:col-span-2">
                <p className="text-sm text-amber-600">
                  <span className="font-medium">Nota:</span> {geoError}
                </p>
              </div>
            )}
            
            {geoLoading && (
              <div className="sm:col-span-2 flex items-center">
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                <span className="text-sm text-gray-500">Obteniendo ubicación...</span>
              </div>
            )}
          </dl>
        </div>
      </div>
      
      <ConfirmationDialog
        isOpen={isConfirmOpen}
        onClose={() => setIsConfirmOpen(false)}
        onConfirm={handleConfirm}
        title={confirmTitle}
        message={confirmMessage}
      />
    </>
  );
}
