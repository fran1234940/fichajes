import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { formatDate, getDaysBetweenDates } from "@/utils/date-utils";
import { cn } from "@/lib/utils";

interface VacationHistoryProps {
  vacationRequests: any[];
  isLoading: boolean;
}

export function VacationHistory({ vacationRequests, isLoading }: VacationHistoryProps) {
  if (isLoading) {
    return (
      <div className="space-y-3">
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-20 w-full" />
      </div>
    );
  }
  
  if (vacationRequests.length === 0) {
    return (
      <div className="text-center py-4 text-gray-500">
        No hay solicitudes de vacaciones.
      </div>
    );
  }
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">
            Pendiente
          </Badge>
        );
      case "approved":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
            Aprobada
          </Badge>
        );
      case "rejected":
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">
            Rechazada
          </Badge>
        );
      default:
        return (
          <Badge variant="outline" className="bg-gray-100 text-gray-800 border-gray-200">
            {status}
          </Badge>
        );
    }
  };
  
  return (
    <div className="space-y-3">
      {vacationRequests.slice(0, 5).map((request) => (
        <div key={request.id} className="p-3 bg-gray-50 rounded-md">
          <div className="flex justify-between items-start">
            <div>
              <div className="text-sm font-medium">
                {formatDate(new Date(request.startDate))} - {formatDate(new Date(request.endDate))}
              </div>
              <div className="text-xs text-gray-500">
                {getDaysBetweenDates(new Date(request.startDate), new Date(request.endDate))} días
              </div>
            </div>
            {getStatusBadge(request.status)}
          </div>
          
          {request.adminResponse && (
            <div className="mt-2 text-xs text-gray-600">
              Respuesta: {request.adminResponse}
            </div>
          )}
        </div>
      ))}
      
      {vacationRequests.length > 5 && (
        <div className="text-center text-sm text-gray-500 mt-2">
          Mostrando 5 de {vacationRequests.length} solicitudes
        </div>
      )}
    </div>
  );
}
